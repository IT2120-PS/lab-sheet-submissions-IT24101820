setwd("C:\\Users\\IT24101820\\Desktop\\IT24101820_Lab_05")
data<-read.table("Data.txt",header=TRUE,sep=",")
fix(data)
attach(data)
names(data)<-c("x1","x2")
attach(data)
hist(x2,main="Histogram for numbers of Shareholders")
histogram<-hist(x2,main="Histogram of Numbers of Shareholders", breaks=seq(130,270,length=8),right=FALSE)
breaks <- round(histogram$breaks)
freq<-histogram$counts
mids<-histogram$mids
classes<-c()
for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")")
}
cbind(Classes=classes, Frequency=freq)
lines(mids,freq)
plot(mids,freq,type="l", main="Frequency Polygen for shareholders",xlab="Shareholders",ylab="Frequency",ylim=c(0,max(freq)))
cum.freq<-cumsum(freq)
new<-c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}
plot(breaks,new,type = "l", main="Cumulative Frequency Polygon for Shareholders",xlab="Shareholders",ylab="Cumulative Frequency", ylim=(c(0,max(cum.freq)))  )
cbind(upper=breaks,Cumfreq=new)

setwd("C:\\Users\\IT24101820\\Desktop\\IT24101820_Lab_05")
Delivery_times<-read.table("Lab05.txt",header=TRUE)
breaks<-seq(20,70,length=5)
hist(Delivery_times$Delivery_Time,breaks=breaks,right=TRUE,main="Delivery Time Histogram",xlab="Delivery Time(minutes)",colours="lightblue",border="black")
freq<-hist(Delivery_times$Delivery_Time,breaks=breaks,right=FALSE,include.lowest = TRUE, plot=FALSE)
cumfreq<-cumsum(freq$counts)
upper_bounds<-freq$breaks[-1]
plot(upper_bounds,cumfreq,type="o",main="Cumulative Frequency Polygon(Ogive)",xlab="Upper Class Boundary",ylab = "Cumulative Frequency")
