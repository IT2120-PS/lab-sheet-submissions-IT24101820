setwd("C:\\Users\\IT24101820\\Desktop\\IT24101820Lab04")

data <- read.table("DATA 4.txt", header=TRUE, sep=" ")
fix(data) 
attach(data)

#part 2 


boxplot(X1 , main= "box plot for attendance", horizontal = TRUE )
boxplot(X2, main="Box plot for Team Salary", horizontal=TRUE)
boxplot(X3, main="Box plot for Years", horizontal=TRUE)


hist(X1, main="Histogram for Team Attendance", xlab="Attendance")
hist(X2, main="Histogram for Team Salary", xlab="Salary")
hist(X3, main="Histogram for Years", xlab="Years")


stem(X1)
stem(X2)
stem(X3)


mean(X1); median(X1); sd(X1)
mean(X2); median(X2); sd(X2)
mean(X3); median(X3); sd(X3)


#part3 

summary(X1); summary(X2); summary(X3)
quantile(X1)[2]  # Q1
quantile(X1)[4]  # Q3


IQR(X1); IQR(X2); IQR(X3)

get.mode <- function(y) {
  counts <- table(y)
  names(counts[counts == max(counts)])
}
get.mode(X3)


#part 4 

get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", lb))
  print(paste("Outliers:", paste(sort(z[z < lb | z > ub]), collapse=",")))
}
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)






##EXERCISE 

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")


str(branch_data)


# Step 3: Boxplot for Sales
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        xlab = "Sales",
        col = "lightblue",
        horizontal = TRUE)

# Step 4: Five-number summary and IQR for Advertising
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# Step 5: Function to find outliers and apply to Years
find_outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  outliers <- x[x < lb | x > ub]
  return(outliers)
}

find_outliers(branch_data$Years_X3)
